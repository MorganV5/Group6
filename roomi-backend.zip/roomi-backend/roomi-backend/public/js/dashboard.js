document.addEventListener("DOMContentLoaded", function () {
    const taskList = document.querySelector(".task-list");
    const completedTasks = document.querySelector(".completed-tasks");
    const weekFilter = document.getElementById("weekFilter");
    const monthFilter = document.getElementById("monthFilter");
    const addTaskButton = document.getElementById("addTask");

    let userId = localStorage.getItem("userId") || 1; // 默认用户ID为1，登录成功后可设置
    let tasks = [];
    let completed = [];

    let currentFilter = localStorage.getItem("taskFilter") || "week";

    function getDaysRemaining(dueDate) {
        if (!dueDate) return Infinity;
        const due = new Date(dueDate);
        if (isNaN(due)) return Infinity;
        const today = new Date();
        const diffTime = due.setHours(0, 0, 0, 0) - today.setHours(0, 0, 0, 0);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    async function fetchTasks() {
        try {
            const response = await fetch(`/tasks/${userId}`);
            tasks = await response.json();
            renderTasks();
        } catch (err) {
            console.error("❌ Failed to fetch tasks:", err);
        }
    }

    function renderTasks() {
        taskList.innerHTML = "";
        completedTasks.innerHTML = "";
      
        let filteredTasks = tasks.filter(task => {
          let daysRemaining = getDaysRemaining(task.due_date);
          if (daysRemaining === Infinity) return false;
          return currentFilter === "week" ? daysRemaining <= 7 : daysRemaining <= 31;
        });
      
        filteredTasks.sort((a, b) => new Date(a.due_date) - new Date(b.due_date));
      
        filteredTasks.forEach(task => {
          const taskItem = document.createElement("li");
          taskItem.classList.add("task-item");
          taskItem.innerHTML = `
            <span class="task-name">${task.name}</span>
            <span class="due-text">Due in ${getDaysRemaining(task.due_date)} days</span>
            <button class="edit-btn" data-task-id="${task.id}">✏️</button>
          `;
          taskList.appendChild(taskItem);
      
          // ✅ 编辑按钮绑定点击事件
          const editButton = taskItem.querySelector(".edit-btn");
          editButton.addEventListener("click", (e) => {
            const taskId = e.target.dataset.taskId;
            window.location.href = `edit_task.html?id=${taskId}`;
          });
        });
      }
      
    weekFilter.addEventListener("click", () => {
        currentFilter = "week";
        localStorage.setItem("taskFilter", "week");
        weekFilter.classList.add("active");
        monthFilter.classList.remove("active");
        renderTasks();
    });

    monthFilter.addEventListener("click", () => {
        currentFilter = "month";
        localStorage.setItem("taskFilter", "month");
        monthFilter.classList.add("active");
        weekFilter.classList.remove("active");
        renderTasks();
    });


    // 初始化筛选按钮状态
    if (currentFilter === "week") {
        weekFilter.classList.add("active");
        monthFilter.classList.remove("active");
    } else {
        monthFilter.classList.add("active");
        weekFilter.classList.remove("active");
    }

    fetchTasks(); // 页面加载后立即从数据库加载任务
});
