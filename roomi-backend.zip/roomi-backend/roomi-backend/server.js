console.log("✅ This is the 2.0 version of server.js");

const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const multer = require("multer");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static("public"));
app.use('/cs7026', express.static('/home/ubuntu/cs7026'));


// MySQL connection
const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "lishufeng.",
    database: "task_management",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });
  


// Multer storage for profile picture upload
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "public/uploads");
    },
    filename: function (req, file, cb) {
        const uniqueName = Date.now() + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});

const upload = multer({ storage });

// ===================
// 📌 API Routes
// ===================

// 👉 Registration with file upload
app.post("/register", upload.single("profile_picture"), (req, res) => {
    const {
        name,
        email,
        password,
        phone,
        flatCode,
        aboutMe
    } = req.body;

    const profile_picture = req.file ? `/uploads/${req.file.filename}` : null;

    const sql = `
        INSERT INTO Users (name, email, password, phone, flat_code, about_me, profile_picture)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(sql, [name, email, password, phone, flatCode, aboutMe, profile_picture], (err, result) => {
        if (err) {
            console.error("❌ Registration failed:", err);
            return res.status(500).json({ message: "Registration failed. Try a different email?" });
        }
        console.log("✅ Registered new user:", email);
        res.json({ message: "Registration successful!" });
    });
});

// 👉 Login
app.post("/login", (req, res) => {
    const { email, password } = req.body;

    const sql = "SELECT * FROM Users WHERE email = ? AND password = ?";
    db.query(sql, [email, password], (err, results) => {
        if (err) {
            console.error("❌ Login query failed:", err);
            return res.status(500).json({ success: false, message: "Server error" });
        }

        if (results.length > 0) {
            console.log("✅ Login successful:", email);
            const user = results[0];
            res.json({
                success: true,
                message: "Login successful",
                user: {
                    id: user.id,
                    email: user.email,
                    flat_code: user.flat_code,
                    name: user.name,
                    profile_picture: user.profile_picture
                }
            });
        } else {
            res.json({ success: false, message: "Invalid email or password" });
        }
    });
});

// 👉 Get tasks assigned to user
app.get("/tasks/:userId", (req, res) => {
    const userId = req.params.userId;

    const sql = `SELECT * FROM Tasks WHERE assigned_to_id = ?`;
    db.query(sql, [userId], (err, results) => {
        if (err) {
            console.error("❌ Failed to get tasks:", err);
            res.status(500).json({ message: "Error fetching tasks" });
        } else {
            res.json(results);
        }
    });
});
// 👉 Add new task
app.post("/tasks", (req, res) => {
    const {
        name,
        description,
        due_date,
        repeat_frequency,
        area_id,
        creator_id,
        assigned_to_id
    } = req.body;

    if (!name || !creator_id) {
        return res.status(400).json({ message: "Missing required fields" });
    }

    const sql = `
        INSERT INTO Tasks 
        (name, description, due_date, repeat_frequency, area_id, creator_id, assigned_to_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(sql, [name, description, due_date, repeat_frequency, area_id, creator_id, assigned_to_id || null], (err, result) => {
        if (err) {
            console.error("❌ Failed to add task:", err);
            return res.status(500).json({ message: "Failed to add task" });
        }
        console.log("✅ Task added:", name);
        res.status(201).json({ message: "Task added successfully" });
    });
});
// 👉 Get all users (for assigning tasks)
app.get("/users", (req, res) => {
    const sql = "SELECT id, name FROM Users";

    db.query(sql, (err, results) => {
        if (err) {
            console.error("❌ Failed to get users:", err);
            return res.status(500).json({ message: "Error fetching users" });
        }
        res.json(results); // 返回用户 ID 和名字
    });
});
// 👉 Get all areas
app.get("/areas", (req, res) => {
    const sql = "SELECT id, name FROM Area";
  
    db.query(sql, (err, results) => {
      if (err) {
        console.error("❌ Failed to get areas:", err);
        return res.status(500).json({ message: "Error fetching areas" });
      }
      res.json(results);
    });
  });
  
  // 👉 Get all task frequencies
  app.get("/frequencies", (req, res) => {
    const sql = "SELECT id, frequency FROM Task_Frequency";
  
    db.query(sql, (err, results) => {
      if (err) {
        console.error("❌ Failed to get frequencies:", err);
        return res.status(500).json({ message: "Error fetching frequencies" });
      }
      res.json(results);
    });
  });
  

  app.post("/tasks/update", (req, res) => {
    const {
      id,
      name,
      description,
      due_date,
      repeat_frequency,
      area_id,
      assigned_to_id
    } = req.body;
  
    const sql = `
      UPDATE Tasks SET
        name = ?,
        description = ?,
        due_date = ?,
        repeat_frequency = ?,
        area_id = ?,
        assigned_to_id = ?
      WHERE id = ?
    `;
  
    db.query(sql, [name, description, due_date, repeat_frequency, area_id, assigned_to_id || null, id], (err, result) => {
      if (err) {
        console.error("❌ Failed to update task:", err);
        return res.status(500).json({ message: "Update failed" });
      }
      res.json({ message: "Task updated!" });
    });
  });
  // 👉 Get a single task by ID (for editing)
app.get("/task/:id", (req, res) => {
    const taskId = req.params.id;
    const sql = "SELECT * FROM Tasks WHERE id = ?";
    db.query(sql, [taskId], (err, results) => {
      if (err) {
        console.error("❌ Failed to fetch task:", err);
        return res.status(500).json({ message: "Error fetching task" });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(results[0]);
    });
  });

  // 👉 Delete a task by ID
app.delete("/tasks/delete/:id", (req, res) => {
    const taskId = req.params.id;
    const sql = "DELETE FROM Tasks WHERE id = ?";
    db.query(sql, [taskId], (err, result) => {
      if (err) {
        console.error("❌ Failed to delete task:", err);
        return res.status(500).json({ message: "Failed to delete task" });
      }
      res.json({ message: "Task deleted successfully" });
    });
  });
  
// ===================
// ✅ Start the server
// ===================
app.listen(PORT, () => {
    console.log(`🚀 Server is running at http://localhost:${PORT}`);
});